const sqlite3 = require("sqlite3").verbose();
const fs = require("fs");
const db = new sqlite3.Database("./data/store.db");
const sql = fs.readFileSync("./product_sqlite_ready.sql", "utf8");

db.exec(sql, err => {
  if (err) console.error("Error initializing DB:", err);
  else console.log("Database created.");
  db.close();
});