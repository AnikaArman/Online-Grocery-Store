
-- SQLite compatible products table
DROP TABLE IF EXISTS products;

CREATE TABLE products (
  id INTEGER PRIMARY KEY,
  name TEXT,
  price REAL,
  unit TEXT,
  stock INTEGER,
  image TEXT
);

-- Sample data with mock image filenames added
INSERT INTO products (id, name, price, unit, stock, image) VALUES
(1000, 'Fish Fingers', 2.55, '500 gram', 1500, 'fish_fingers_500.jpg'),
(1001, 'Fish Fingers', 5.00, '1000 gram', 750, 'fish_fingers_1000.jpg'),
(1002, 'Hamburger Patties', 2.35, 'Pack 10', 1200, 'hamburger_patties.jpg'),
(1003, 'Shelled Prawns', 6.90, '250 gram', 300, 'shelled_prawns.jpg'),
(1004, 'Tub Ice Cream', 1.80, '1 Litre', 800, 'ice_cream_1l.jpg'),
(1005, 'Tub Ice Cream', 3.40, '2 Litre', 1200, 'ice_cream_2l.jpg');
